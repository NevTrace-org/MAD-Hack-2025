﻿namespace Qubik.Hackathon.API.Models
{
    public class Milestone
    {
    }
}
