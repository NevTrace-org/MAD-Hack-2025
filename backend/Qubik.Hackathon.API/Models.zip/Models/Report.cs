﻿namespace Qubik.Hackathon.API.Models
{
    public class Report
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
    }
}
