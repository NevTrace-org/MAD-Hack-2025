﻿namespace Qubik.Hackathon.API.Models
{
    public class Investment
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public int Quantity { get; set; }   
    }
}
